#include<stdio.h>

int main()
{
    int Number1, Number2, Number3, Average, Sum, Multiplication;

    printf("Enter the first number:\n");
    scanf("d", &Number1);

    printf("Enter the second number:\n");
    scanf("d", &Number2);

    printf("Enter the third number:\n");
    scanf("d", &Number3);

    Average = (Number1 + Number2 + Number3) / 3;
    Sum = Number1 + Number2 + Number3;
    Multiplication = Number1 * Number2 * Number3;

    printf("The average is %d\n", Average);
    printf("The sum is: %d\n", Sum);
    printf("The multiplication is %d\n", Multiplication);

    return 0;

}
