#include<stdio.h>

int main()
{
    int Number;
    int Digit1, Digit2, Digit3, Digit4, Digit5;

    printf("Enter number with five digits: ");
    scanf("%d", &Number);

    Digit1 = Number % 10;
    Digit2 = (Number / 10) % 10;
    Digit3 = (Number / 100) % 10;
    Digit4 = (Number / 1000) % 10;
    Digit5 = (Number / 10000) % 10;

    printf("%d   %d   %d   %d   %d\n", Digit1, Digit2, Digit3, Digit4, Digit5);;

    return 0;
}
