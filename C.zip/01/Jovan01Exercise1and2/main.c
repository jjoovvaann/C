/* Find the mistakes
a) scanf(“d”, vrednost);
b) printf(“Proizvodot na %d i %d e %d”\n, x, y);
c) prvBroj + vtorBroj = sumaBroevi
d) */ /* Programata naogja maksimum od dva broja/*
e) Scanf(”%d”, &nekojBroj); */


/* a) First mistake: it should be %d(for reading the integer) and second mistake: it should be &vrednost because it must have address operator
   b) "" should be after \n and it's missing one more argument, for example x,y,multiplication
   c) First it should be the variable, sumaBroevi = prvBroj + vtor broj
   d) It is comment, but it should be /* and */
 /*  e) Scanf with lower letter */


#include <stdio.h>

int main()
{
    int number1, number2, number3, number4, sum;

    printf("Enter the first number: \n");
    scanf("%d", &number1);

    printf("Enter the second number: \n");
    scanf("%d", &number2);

    printf("Enter the third number: \n");
    scanf("%d", &number3);

    printf("Enter the fourth number: \n");
    scanf("%d", &number4);

    sum = number1 + number2 + number3 + number4;

    printf("The sum is: %d\n", sum);

    return 0;
}
