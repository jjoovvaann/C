#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int palindrom(char str[])
{
    int length = strlen(str);
    bool isPalindrome = true;

    for (int i = 0; i < length / 2; i++)
    {
        if (str[i] != str[length - i - 1])
        {
            isPalindrome = false;
            break;
        }
    }

    return isPalindrome ? 1 : 0;
}

int main()
{
    char str[100];
    printf("Enter a string: ");
    scanf("%s", str);

    if (palindrom(str))
    {
        printf("The entered string is a palindrome.\n");
    }
    else
    {
        printf("The entered string is not a palindrome.\n");
    }

    return 0;
}
