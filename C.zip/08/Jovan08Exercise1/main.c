#include <stdio.h>

int main()
{
    int days_in_month;
    printf("Enter the number of days in the month: ");
    scanf("%d", &days_in_month);

    int temperatures[days_in_month];
    int sum = 0;

    printf("Enter temperatures for each day of the month:\n");

    for (int i = 0; i < days_in_month; ++i)
    {
        printf("Enter temperature for day %d: ", i + 1);
        scanf("%d", &temperatures[i]);
        sum += temperatures[i];
    }

    double average_temperature = (double)sum / days_in_month;
    printf("Average monthly temperature: %.2f\n", average_temperature);

    return 0;
}
