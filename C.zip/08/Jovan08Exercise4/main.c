#include <stdio.h>

void vnesiMatrica(int rows, int cols, int matrica[rows][cols])
{
    printf("Enter elements for the matrix:\n");
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            printf("Enter element at position [%d][%d]: ", i, j);
            scanf("%d", &matrica[i][j]);
        }
    }
}

void pechatiMatrica(int rows, int cols, int matrica[rows][cols])
{
    printf("Matrix elements:\n");
    for (int i = 0; i < rows; ++i)
    {
        for (int j = 0; j < cols; ++j)
        {
            printf("%d\t", matrica[i][j]);
        }
        printf("\n");
    }
}
