#include <stdio.h>

float calculateMean(int arr[], int n)
{
    int sum = 0;
    for (int i = 0; i < n; ++i)
    {
        sum += arr[i];
    }
    return (float)sum / n;
}

float calculateMedian(int arr[], int n)
{
    if (n % 2 != 0)
    {
        return arr[n / 2];
    } else
    {
        return (arr[n / 2 - 1] + arr[n / 2]) / 2.0;
    }
}

void calculateFrequencyAndHistogram(int arr[], int n)
{
    int maxFreq = 0, mostFreqValue = arr[0];
    printf("Histogram:\n");

    for (int i = 0; i < n; ++i)
    {
        int count = 1;

        for (int j = i + 1; j < n; ++j)
        {
            if (arr[i] == arr[j])
            {
                ++count;
            }
        }

        if (count > maxFreq)
        {
            maxFreq = count;
            mostFreqValue = arr[i];
        }

        printf("%d: ", arr[i]);
        for (int k = 0; k < count; ++k)
        {
            printf("*");
        }
        printf("\n");
    }

    printf("Most frequent value: %d\n", mostFreqValue);
}

int main()
{
    int n;
    printf("Enter the number of elements (n): ");
    scanf("%d", &n);

    int arr[100];
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; ++i)
    {
        scanf("%d", &arr[i]);
    }

    printf("Mean: %.2f\n", calculateMean(arr, n));

    for (int i = 0; i < n - 1; ++i)
    {
        for (int j = 0; j < n - i - 1; ++j)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    printf("Median: %.2f\n", calculateMedian(arr, n));
    calculateFrequencyAndHistogram(arr, n);

    return 0;
}
