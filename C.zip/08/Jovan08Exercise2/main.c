#include <stdio.h>
#include <stdbool.h>

void prosti(int arr[], int n)
{
    for (int i = 2; i < n; ++i)
    {
        if (arr[i] == 1)
        {
            for (int j = 2; i * j < n; ++j)
            {
                arr[i * j] = 0;

            }
        }
    }
}

void printPrimes(int arr[], int n)
{
    printf("Prime numbers in the array: ");
    for (int i = 2; i < n; ++i)
    {
        if (arr[i] == 1)
        {
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main() {
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];
    for (int i = 0; i < n; ++i) {
        arr[i] = 1;
    }

    prosti(arr, n);
    printPrimes(arr, n);

    return 0;
}
