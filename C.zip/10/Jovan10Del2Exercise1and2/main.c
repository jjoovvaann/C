/* refers to the fact that the destination array (referred to by s1 in copy1 and copy2 functions)
 * must have enough space to hold the contents of the source string (s2). */


/* Const correctness: It tells the compiler that the value pointed to by s2 should not be changed via this reference */
