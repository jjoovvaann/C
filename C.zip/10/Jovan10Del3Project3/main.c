#include <stdio.h>

void pecatiNiza(int *niza, int redici, int koloni)
{
    int i, j;
    for (i = 0; i < redici; i++)
    {
        for (j = 0; j < koloni; j++)
        {
            printf("%d ", *(niza + i * koloni + j));
        }
        printf("\n");
    }
}

int max(int *niza, int redici, int koloni)
{
    int maxOcena = *niza;
    int i, j;
    for (i = 0; i < redici; i++)
    {
        for (j = 0; j < koloni; j++)
        {
            if (*(niza + i * koloni + j) > maxOcena)
            {
                maxOcena = *(niza + i * koloni + j);
            }
        }
    }
    return maxOcena;
}

int min(int *niza, int redici, int koloni)
{
    int minOcena = *niza;
    int i, j;
    for (i = 0; i < redici; i++)
    {
        for (j = 0; j < koloni; j++)
        {
            if (*(niza + i * koloni + j) < minOcena)
            {
                minOcena = *(niza + i * koloni + j);
            }
        }
    }
    return minOcena;
}

void proseka(int *niza, int redici, int koloni)
{
    int i, j;
    for (i = 0; i < redici; i++)
    {
        float sum = 0.0;
        for (j = 0; j < koloni; j++)
        {
            sum += *(niza + i * koloni + j);
        }
        float average = sum / koloni;
        printf("Prosek za student %d: %.2f\n", i + 1, average);
    }
}

int main() {
    int niza[100][5]; \
    int redici, koloni;
    printf("Vnesi broj na studenti: ");
    scanf("%d", &redici);

    printf("Vnesi broj na oceni po student: ");
    scanf("%d", &koloni);

    printf("Vnesi ocenite:\n");
    int i, j;
    for (i = 0; i < redici; i++)
    {
        printf("Student %d:\n", i + 1);
        for (j = 0; j < koloni; j++)
        {
            scanf("%d", &niza[i][j]);
        }
    }

    int (*obrabotiOceni[4])(int *niza, int redici, int koloni) = {max, min, NULL, proseka};

    int choice;
    do {
        printf("\nVnesi izbor:\n");
        printf("0 Ispecati ja nizata so oceni\n");
        printf("1 Najdi ja maksimalnata ocena\n");
        printf("2 Najdi ja minimalnata ocena\n");
        printf("3 Ispecati ja prosechnata ocena za sekoja student\n");
        printf("4 Kraj\n");
        scanf("%d", &choice);

        if (choice >= 0 && choice <= 3)
        {
            if (choice == 2) choice = 1;

            if (obrabotiOceni[choice] != NULL)
            {
                printf("Rezultat: %d\n", (*obrabotiOceni[choice])((int *)niza, redici, koloni));
            } else
            {
                (*obrabotiOceni[choice])((int *)niza, redici, koloni);
            }
        } else if (choice != 4)
        {
            printf("Nevaliden izbor. Probajte povtorno.\n");
        }
    } while (choice != 4);

    return 0;
}
