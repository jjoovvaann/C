#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

#define HAND_SIZE 5

void meshaj(int wDeck[][13]);
void deli(const int wDeck[][13], const char *wFace[], const char *wSuit[]);
bool checkPair(const int hand[]);
bool checkTwoPairs(const int hand[]);
bool checkThreeOfAKind(const int hand[]);
bool checkFourOfAKind(const int hand[]);
bool checkFlush(const int hand[]);
bool checkStraight(const int hand[]);

int main()
{
    const char *boja[4] = {"Srce", "Karo", "List", "Detelina"};
    const char *brojka[13] = {"As", "Dva", "Tri","Chetiri","Pet"
    , "Shest","Sedum","Osum","Devet","Deset","Dzandar","Dama","Pop"};
    int spil[4][13] = {0};
    srand(time(0));
    meshaj(spil);
    deli(spil, brojka, boja);

    return 0;
}

void meshaj(int wDeck[][13])
{
    int row;
    int column;
    int card;

    for(card = 1;card<=52; card++)
    {
        do
        {
            row = rand() % 4;
            column = rand()%13;
        } while (wDeck[row][column]!=0);
        wDeck[row][column] = card;
    }
}

void deli(const int wDeck[][13], const char *wFace[], const char *wSuit[])
{
    int hand[HAND_SIZE] = {0};
    int cardIndex = 0;

    for (int card = 1; card <= 52; card++)
    {
        for (int row = 0; row <= 3; row++)
        {
            for (int column = 0; column <= 12; column++)
            {
                if (wDeck[row][column] == card && cardIndex < HAND_SIZE)
                {
                    hand[cardIndex++] = column * 4 + row + 1;

                    if (cardIndex == HAND_SIZE)
                    {
                        printf("Hand: ");
                        for (int i = 0; i < HAND_SIZE; i++)
                        {
                            printf("%s %s%s", wFace[hand[i] % 13], wSuit[hand[i] / 13], (i == HAND_SIZE - 1) ? "\n" : ", ");
                        }


                        if (checkPair(hand))
                        {
                            printf("Hand contains a pair.\n");
                        }
                        if (checkTwoPairs(hand))
                        {
                            printf("Hand contains two pairs.\n");
                        }
                        if (checkThreeOfAKind(hand))
                        {
                            printf("Hand contains three of a kind.\n");
                        }
                        if (checkFourOfAKind(hand))
                        {
                            printf("Hand contains four of a kind.\n");
                        }
                        if (checkFlush(hand))
                        {
                            printf("Hand contains a flush.\n");
                        }
                        if (checkStraight(hand))
                        {
                            printf("Hand contains a straight.\n");
                        }
                    }
                }
            }
        }
    }
}
#include <stdbool.h>

bool checkPair(const int hand[])
{
    for (int i = 0; i < 4; ++i)
    {
        for (int j = i + 1; j < 5; ++j)
        {
            if (hand[i] % 13 == hand[j] % 13)
            {
                return true;
            }
        }
    }
    return false;
}

bool checkTwoPairs(const int hand[])
{
    int pairs = 0;
    for (int i = 0; i < 4; ++i)
    {
        for (int j = i + 1; j < 5; ++j)
        {
            if (hand[i] % 13 == hand[j] % 13)
            {
                pairs++;
            }
        }
    }
    return (pairs == 2);
}

bool checkThreeOfAKind(const int hand[])
{
    for (int i = 0; i < 3; ++i)
    {
        int count = 0;
        for (int j = i + 1; j < 5; ++j)
        {
            if (hand[i] % 13 == hand[j] % 13)
            {
                count++;
            }
        }
        if (count == 2)
        {
            return true;
        }
    }
    return false;
}

bool checkFourOfAKind(const int hand[])
{
    for (int i = 0; i < 2; ++i)
    {
        int count = 0;
        for (int j = i + 1; j < 5; ++j)
        {
            if (hand[i] % 13 == hand[j] % 13)
            {
                count++;
            }
        }
        if (count == 3) {
            return true;
        }
    }
    return false;
}

bool checkFlush(const int hand[])
{
    int suit = hand[0] / 13;
    for (int i = 1; i < 5; ++i)
    {
        if (hand[i] / 13 != suit)
        {
            return false;
        }
    }
    return true;
}

bool checkStraight(const int hand[])
{
    for (int i = 0; i < 4; ++i)
    {
        if ((hand[i] + 1) % 13 != hand[i + 1] % 13)
        {
            return false;
        }
    }
    return true;
}
