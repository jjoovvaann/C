#include <stdio.h>

void dzvezdi(int n)
{
    if (n == 0) {
        printf("\n");
        return;
    }

    for (int i = 0; i < n; ++i)
    {
        printf("* ");
    }
    printf("\n");

    dzvezdi(n - 1);
}

int main()
{
    int n;
    printf("Enter the number of stars (n): ");
    scanf("%d", &n);

    printf("Result:\n");
    dzvezdi(n);

    return 0;
}
