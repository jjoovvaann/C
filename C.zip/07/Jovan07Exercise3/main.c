#include <stdio.h>

int obratno(int number) {
    int reverse = 0;
    while (number > 0) {
        int digit = number % 10;
        reverse = reverse * 10 + digit;
        number /= 10;
    }
    return reverse;
}

int main() {
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    int reversed_num = obratno(num);
    printf("The reversed number is: %d\n", reversed_num);

    return 0;
}

