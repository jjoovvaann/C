#include <stdio.h>

int greatest_common_divisor(int a, int b)
{
    while (b != 0)
    {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

int main()
{
    int number1, number2;
    printf("Enter the first number: ");
    scanf("%d", &number1);
    printf("Enter the second number: ");
    scanf("%d", &number2);

    int gcd = greatest_common_divisor(number1, number2);
    printf("The greatest common divisor of %d and %d is: %d\n", number1, number2, gcd);

    return 0;
}
