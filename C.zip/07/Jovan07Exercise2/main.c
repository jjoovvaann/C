#include <stdio.h>

int vreme(int hour, int minute, int second)
{
    int seconds_until_12 = 12 * 3600;
    int total_seconds = hour * 3600 + minute * 60 + second;
    int remaining_seconds = seconds_until_12 - total_seconds;
    return remaining_seconds;
}

int main() {
    int hour, minute, second;
    printf("Enter hour: ");
    scanf("%d", &hour);
    printf("Enter minute: ");
    scanf("%d", &minute);
    printf("Enter second: ");
    scanf("%d", &second);

    int remaining_seconds = vreme(hour, minute, second);
    printf("Remaining seconds until 12 o'clock: %d seconds\n", remaining_seconds);

    return 0;
}
