#include <stdio.h>

int paren(int number)
{
    if (number % 2 == 0)
    {
        return 1;
    } else
    {
        return 0;
    }
}

int main()
{
    int numbers[10];
    int results[10];

    printf("Enter 10 numbers:\n");
    for (int i = 0; i < 10; i++)
    {
        scanf("%d", &numbers[i]);
    }

    for (int i = 0; i < 10; i++)
    {
        results[i] = paren(numbers[i]);
    }

    printf("Results: ");
    for (int i = 0; i < 10; i++)
    {
        printf("%d ", results[i]);
    }
    printf("\n");

    return 0;
}
