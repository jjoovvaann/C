#include <stdio.h>

struct Node
{
    int broj;
    char karakter;
    struct Node* next;
};

void pecatiListaNanazad(struct Node* head)
{
    if (head == NULL)
    {
        return;
    }
    pecatiListaNanazad(head->next);
    printf("%d %c\n", head->broj, head->karakter);
}


int main()
{
    struct Node* head = NULL;
    struct Node* second = NULL;
    struct Node* third = NULL;

    head = (struct Node*)malloc(sizeof(struct Node));
    second = (struct Node*)malloc(sizeof(struct Node));
    third = (struct Node*)malloc(sizeof(struct Node));

    head->broj = 1;
    head->karakter = 'A';
    head->next = second;

    second->broj = 2;
    second->karakter = 'B';
    second->next = third;

    third->broj = 3;
    third->karakter = 'C';
    third->next = NULL;

    printf("Pecati lista nanazad:\n");
    pecatiListaNanazad(head);

    return 0;
}
