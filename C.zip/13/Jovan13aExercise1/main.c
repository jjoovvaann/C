#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct stackNode
{
    char data;
    struct stackNode *nextPtr;
};

typedef struct stackNode StackNode;
typedef StackNode *StackNodePtr;


StackNodePtr createStackNode(char data)
{
    StackNodePtr newNode = (StackNodePtr)malloc(sizeof(StackNode));
    newNode->data = data;
    newNode->nextPtr = NULL;
    return newNode;
}


int isEmpty(StackNodePtr topPtr)
{
    return topPtr == NULL;
}


void push(StackNodePtr *topPtr, char data)
{
    StackNodePtr newNode = createStackNode(data);
    newNode->nextPtr = *topPtr;
    *topPtr = newNode;
}


char pop(StackNodePtr *topPtr)
{
    if (isEmpty(*topPtr))
    {
        return '\0';
    }
    StackNodePtr temp = *topPtr;
    *topPtr = (*topPtr)->nextPtr;
    char popped = temp->data;
    free(temp);
    return popped;
}


void printReverse(StackNodePtr topPtr)
{
    printf("Text in reverse order: ");
    while (!isEmpty(topPtr))
    {
        printf("%c", pop(&topPtr));
    }
    printf("\n");
}

int main()
{
    char text[100];
    printf("Enter text: ");
    fgets(text, sizeof(text), stdin);

    StackNodePtr stackPtr = NULL;


    for (int i = 0; i < strlen(text); i++)
    {
        push(&stackPtr, text[i]);
    }

    printReverse(stackPtr);

    return 0;
}
