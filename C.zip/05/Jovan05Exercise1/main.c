#include <stdio.h>

int main()
{
    int number;
    int sum;


    for ( int sum = 0, number = 2; number <= 100; number += 2 )
    {
        sum += number;
    }

    printf( "Sum is %d\n", sum );

    return 0;
}
