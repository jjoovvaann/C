#include <stdio.h>

int main() {
    int a, b, c;

    printf("Pythagorean Numbers up to 100:\n");
    printf("a\tb\tc\n");

    for (a = 1; a <= 100; a++) {
        for (b = a; b <= 100; b++) {
            for (c = b; c <= 100; c++) {
                if (a * a + b * b == c * c) {
                    printf("%d\t%d\t%d\n", a, b, c);
                }
            }
        }
    }

    return 0;
}
