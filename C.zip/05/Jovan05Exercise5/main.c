#include <stdio.h>

int main()
{
    int x;

    for ( x = 1; x <= 100; x++ )
    {


        if ( x % 3 == 0 )
        {
            continue;
        }
        else
        {
        printf( "%d can't be divided with 3\n", x );
        }
    }



    return 0;

}
