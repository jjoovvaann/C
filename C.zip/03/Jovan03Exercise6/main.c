#include <stdio.h>

int main() {
    char letters[5];
    char temp;

    printf("Enter five letters: \n");

    printf("First letter: ");
    scanf(" %c", &letters[0]);

    printf("Second letter: ");
    scanf(" %c", &letters[1]);

    printf("Third letter: ");
    scanf(" %c", &letters[2]);

    printf("Fourth letter: ");
    scanf(" %c", &letters[3]);

    printf("Fifth letter: ");
    scanf(" %c", &letters[4]);

    temp = letters[0];
    letters[0] = letters[4];
    letters[4] = letters[2];
    letters[2] = letters[1];
    letters[1] = temp;

    printf("Result: %c%c%c%c%c\n", letters[0], letters[1], letters[2], letters[3], letters[4]);

    return 0;
}

