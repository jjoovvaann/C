#include <stdio.h>

int main()
{
    printf("%d", 'A');

    printf("%d", 'b');
    printf("%d", 'c');
    printf("%d", '0');
    printf("%d", '1');
    printf("%d", '2');
    printf("%d", '$');
    printf("%d", '*');
    printf("%d", '+');
    printf("%d", '/');
    printf("%d", ' ');
    return 0;
}
/* it prints the ASCII codes */
