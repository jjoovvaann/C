#include <stdio.h>

int main()
{
    int number1, number2;

    printf("Enter the first number: ");
    scanf("%d", &number1);

    printf("Enter the second number: ");
    scanf("%d", &number2);

    if (number1 % 2 == 0)
    {
        printf("%d is even number.\n", number1);
    }
    else
    {
        printf("%d is odd number.\n", number1);
    }

    if (number2 % 2 == 0)
    {
        printf("%d is even number.\n", number2);
    }
    else
    {
        printf("%d is odd number.\n", number2);
    }

    return 0;
}
