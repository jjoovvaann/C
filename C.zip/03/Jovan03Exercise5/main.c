#include<stdio.h>
int main()
{
    float radius, pi, area, perimetar;
    pi = 3.14;
    printf("Enter the radius of the circle: ");
    scanf("%.2f ", &radius);

    area = radius*radius*pi;
    perimetar = 2*radius*pi;

    printf("The area is: %.2f\n", area);
    printf("The perimetar is: %.2f\n", perimetar);

    return 0;
}
