#include<stdio.h>

int main()
{
    int number1, number2;
    printf("Enter the first number: \n");
    scanf("%d ", &number1);

    printf("Enter the second number: \n");
    scanf("%d ", &number2);

    if(number1 > number2);
    {
        printf("%d is bigger than %d", number1, number2);
    }

    if(number2 > number1);
    {
        printf("%d is bigger than %d", number2, number1);
    }

    if(number1 == number2);
    {
        printf("%d is equal to %d", number1, number2);
    }

    return 0;
}
