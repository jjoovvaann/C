#include <stdio.h>

void printIncreasingSubarrays(int arr[], int n) {
    int start = 0, end = 0;

    for (int i = 1; i < n; i++) {
        if (arr[i] > arr[i - 1]) {
            end = i;
        } else {
            if (start != end) {
                printf("Increasing subarray: ");
                for (int j = start; j <= end; j++) {
                    printf("%d ", arr[j]);
                }
                printf("\n");
            }
            start = i;
            end = i;
        }
    }

    if (start != end) {
        printf("Increasing subarray: ");
        for (int j = start; j <= end; j++) {
            printf("%d ", arr[j]);
        }
        printf("\n");
    }
}

int main() {
    int n;

    printf("Enter the size of the array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter the elements of the array:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Increasing subarrays in the array:\n");
    printIncreasingSubarrays(arr, n);

    return 0;
}
