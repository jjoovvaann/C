#include <stdio.h>
#include <math.h>

int main()
{
    int n, i, j, k;
    float x;

    printf("Enter the initial number of bacteria: ");
    scanf("%d", &n);

    printf("Enter the time after which bacteria divide (in minutes): ");
    scanf("%d", &i);

    printf("Enter the time after which bacteria die (in minutes): ");
    scanf("%d", &j);

    printf("Enter the percentage of bacteria dying: ");
    scanf("%f", &x);

    printf("Enter the total time (in minutes): ");
    scanf("%d", &k);

    int timePassed = 0;
    while (timePassed < k)
    {
        timePassed += i;


        int doubling = n;
        n *= 2;


        if (timePassed >= k)
        {
            printf("After %d minutes, the number of bacteria is: %d\n", k, n);
            break;
        }


        int death = round(doubling * (x / 100));
        n -= death * 2;

        timePassed += j;
    }

    return 0;
}
