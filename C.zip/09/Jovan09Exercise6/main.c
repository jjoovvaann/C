#include <stdio.h>

int sumOfCubesOfDigits(int num)
{
    int sum = 0;

    while (num > 0) {
        int digit = num % 10;
        sum += digit * digit * digit;
        num /= 10;
    }

    return sum;
}

void findNumbers(int n)
{
    printf("Natural numbers smaller than %d where the sum of cubes of digits equals the number:\n", n);
    for (int i = 1; i < n; i++) {
        if (sumOfCubesOfDigits(i) == i)
        {
            printf("%d\n", i);
        }
    }
}

int main()
{
    int n;

    printf("Enter a number: ");
    scanf("%d", &n);

    findNumbers(n);

    return 0;
}
