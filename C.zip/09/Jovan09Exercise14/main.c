#include <stdio.h>

void printLine(int n)
{
    if (n == 0) {
        return;
    }
    printf("%d ", n);
    printLine(n - 1);
}

void printPattern(int n)
{
    if (n == 0)
    {
        return;
    }
    printLine(n);
    printf("\n");
    printPattern(n - 1);
    printLine(n);
    printf("\n");
}

int main()
{
    int n;

    printf("Enter a natural number: ");
    scanf("%d", &n);

    printPattern(n);

    return 0;
}
