#include<stdio.h>

int main()
{
    int n;
    float side_length;
    float perimeter;

    printf("Enter the number of sides: ");
    scanf("%d", &n);

    printf("Enter the length: ");
    scanf("%d", &side_length);

    perimeter = n * side_length;


    printf("The perimeter of the polygon is: %d\n", perimeter);
    ;

    return 0;
}

