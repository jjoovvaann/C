#include <stdio.h>

int reverseNumber(int n)
{
    int reverse = 0;

    while (n > 0)
    {
        int digit = n % 10;
        reverse = reverse * 10 + digit;
        n /= 10;
    }

    return reverse;
}

void findNumbers(int n1, int n2)
{
    printf("Natural numbers between %d and %d that are divisible by their reverse number:\n", n1, n2);
    for (int i = n1; i <= n2; i++)
    {
        int reversed = reverseNumber(i);
        if (i % reversed == 0) {
            printf("%d\n", i);
        }
    }
}

int main()
{
    int n1, n2;

    printf("Enter the starting number of the interval: ");
    scanf("%d", &n1);
    printf("Enter the ending number of the interval: ");
    scanf("%d", &n2);

    findNumbers(n1, n2);

    return 0;
}
