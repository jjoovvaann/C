#include <stdio.h>

int reverseNumber(int n)
{
    int reverse = 0;

    while (n > 0)
    {
        int digit = n % 10;
        reverse = reverse * 10 + digit;
        n /= 10;
    }

    return reverse;
}

int main()
{
    int n;

    printf("Enter a natural number: ");
    scanf("%d", &n);

    int reversed = reverseNumber(n);

    printf("The reverse of %d is: %d\n", n, reversed);

    return 0;
}
