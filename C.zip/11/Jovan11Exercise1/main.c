#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
    char phone_number[20];
    char *token;
    char phone_number_no_dash[15] = "";
    int country_code;
    long int phone_no;

    printf("Enter the phone number: ");
    fgets(phone_number, sizeof(phone_number), stdin);
    phone_number[strcspn(phone_number, "\n")] = '\0';

    token = strtok(phone_number, "() -");
    country_code = atoi(token);

    while(token!= NULL)
    {
        token = strtok(NULL, "() -");
        if(token != NULL)
        {
            strcat(phone_number_no_dash, token);
        }
    }

    phone_no = atol(phone_number_no_dash);
    printf("Country code: %d\n", country_code);
    printf("Phone number: %ld\n", phone_no);

    return 0;

}
