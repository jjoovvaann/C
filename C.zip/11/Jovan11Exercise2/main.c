#include<stdio.h>
#include<string.h>

void convertDate(char *inputDate, char *outputDate)
{
    char *months[] = {"", "January", "February", "March"
                      , "April", "May", "June"
                      , "July", "August", "Septembar", "October", "November"
                          "December"};
    int day, month, year;
    sscanf(inputDate, "%d/%d/%d", &day, &month, &year);
}

int main()
{
    char inputDate[20];
    int numDates;

    for (int i = 0; i < numDates; ++i)
    {
        printf("Enter the number of dates: ");
        scanf("%d", &numDates);

        fgets(inputDate, sizeof(inputDate), stdin);

        char outputDate[30];
        convertDate(inputDate, outputDate);

        printf("%s\n", outputDate);
    }
    return 0;
}
