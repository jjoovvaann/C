#include <stdio.h>

int main()
{
    int number;
    int sum = 0;

    printf("Enter numbers, -1 to finish\n");

    while(1)
    {
        printf("Enter number: ");
        scanf("%d", &number);

        if(number == -1)
        {
            break;
        }
        sum = sum + number;
    }

    printf("The sum is:%d", sum);

    return 0;
}
