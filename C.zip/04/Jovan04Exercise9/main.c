#include <stdio.h>

int main() {
    double promet;
    double plata;

    do {
        printf("Enter money in euros, (-1 for ending): ");
        scanf("%lf", &promet);

        if (promet != -1) {
            plata = 200 + (promet * 0.09);
            printf("Salary is: %.2lf euros\n", plata);
        }

    } while (promet != -1);

    return 0;
}
