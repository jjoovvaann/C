#include <stdio.h>

int main() {
    int counter = 0;
    int grade;
    int total = 0;
    int average;

    printf("Enter number of students: ");
    scanf("%d", &counter);

    while (counter > 0)
    {
        printf("Enter grade: ");
        scanf("%d", &grade);
        total += grade;
        counter--;
    }

    if (counter == 0)
    {
        average = total / counter;
        printf("Average grade is %d\n", average);
    }
    else
    {
        printf("Invalid number of students.\n");
    }

    return 0;
}

