#include<stdio.h>

int main()
{
    int counter;
    int sum = 0;
    for(counter = 0;counter <= 10;counter++)
    {
        sum = sum+counter;
    }

    printf("The sum is: %d", sum);
    return 0;
}
