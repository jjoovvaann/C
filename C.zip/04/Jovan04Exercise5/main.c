#include <stdio.h>

int main()
{
    int multiplication = 1;
    int counter=1;
    while(counter<=10)
    {
        int number;
        printf("Enter number: ");
        scanf("%d", &number);
        multiplication = multiplication * number;
        counter++;
    }
    printf("The final result is: %d", multiplication);
    return 0;
}
