#include <stdio.h>

int main() {
    char input;
    int number;
    int sum = 0;

    do
    {
        printf("Enter number: ");
        scanf("%d", &number);
        sum += number;

        printf("More calculation?? (y/n): ");
        scanf(" %c", &input);
    }
    while (input != 'n');
    {
        printf("Sum is %d\n", sum);
    }
    return 0;
}


