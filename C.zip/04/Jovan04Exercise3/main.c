#include <stdio.h>

int main()
{
    int numStudents = 0;
    int grade;
    int total = 0;
    float average;

    printf("Enter number of students: ");
    scanf("%d", &numStudents);

    int counter = numStudents;

    while (counter > 0)
    {
        printf("Enter grade: ");
        scanf("%d", &grade);
        total += grade;
        counter--;
    }

    if (numStudents > 0)
    {
        average = (float)total / numStudents;
        printf("Average grade is %.3f\n", average);
    }
    else
    {
        printf("Invalid number of students.\n");
    }

    return 0;
}
