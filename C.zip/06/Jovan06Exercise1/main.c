#include <stdio.h>

int main()
{
    int fahrenheit;
    float celsius;

    for (fahrenheit = 0; fahrenheit <= 212; fahrenheit++)
    {
        celsius = 5.0 / 9.0 * (fahrenheit - 32);
        printf("%10.3f ", celsius);
        if (fahrenheit % 5 == 0)
        {
            printf("\n");
        }
    }

    return 0;
}
