#include <stdio.h>

int main()
{
    int month1;
    int day1;
    int year1;
    int month2;
    int day2;
    int year2;
    int month3;
    int day3;
    int year3;

    char *months[] = {
                      "January", "February", "March", "April", "May", "June",
                      "July", "August", "September", "October", "November", "December"};

    printf("Enter date in the format dd-mm-yyyy: ");
    scanf("%d%*c%d%*c%d", &day1, &month1, &year1);

    printf("day = %d  month = %s  year = %d\n\n", day1, months[month1 - 1], year1);

    printf("Enter date in the format dd/mm/yyyy: ");
    scanf("%d%*c%d%*c%d", &day2, &month2, &year2);

    printf("day = %d  month = %s  year = %d\n", day2, months[month2 - 1], year2);

    printf("Enter date in the format dd+mm+yyyy: ");
    scanf("%d%*c%d%*c%d", &day3, &month3, &year3);

    printf("day = %d  month = %s  year = %d\n", day3, months[month3 - 1], year3);

    return 0;
}
