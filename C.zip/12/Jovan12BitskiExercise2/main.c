#include <stdio.h>

void prikaziBitovi(unsigned int num)
{
    printf("Bitovi pred prevrtuvanje: ");
    for (int i = 31; i >= 0; --i) {
        printf("%u", (num >> i) & 1);
    }
    printf("\n");
}

void prevtriBitovi(unsigned int num)
{
    unsigned int prevrten = 0;
    int bitCount = sizeof(num) * 8;

    for (int i = 0; i < bitCount; ++i)
    {
        prevrten = (prevrten << 1) | (num & 1);
        num >>= 1;
    }

    printf("Bitovi po prevrtuvanje: ");
    for (int i = 31; i >= 0; --i)
    {
        printf("%u", (prevrten >> i) & 1);
    }
    printf("\n");
}

int main()
{
    unsigned int broj;

    printf("Vnesete cel broj: ");
    scanf("%u", &broj);

    prikaziBitovi(broj);
    prevtriBitovi(broj);

    return 0;
}
