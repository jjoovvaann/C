#include <stdio.h>

int mnoziSoStepenOdDva(int broj, int stepen)
{
    return broj << stepen;
}

int main()
{
    int broj, stepen;
    printf("Enter the number: ");
    scanf("%d", &broj);
    printf("Enter the exponent: ");
    scanf("%d", &stepen);

    int rezultat = mnoziSoStepenOdDva(broj, stepen);
    printf("%d * 2^%d = %d\n", broj, stepen, rezultat);

    return 0;
}
